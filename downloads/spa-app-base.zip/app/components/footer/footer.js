// @spa$:footer

// private properties
let _style = '.';

let _data = { companyName: 'XYZ Inc' };
