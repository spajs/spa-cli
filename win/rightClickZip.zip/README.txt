1. Copy files (zip.cmd, rightclickZip.reg) to c:\spa-cli
2. Double-Click rightclickZip.reg file to register context-menu (Zip-Now) for a folder