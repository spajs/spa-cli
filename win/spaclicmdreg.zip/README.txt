1. Copy files to c:\spa-cli
2. Double-Click rightclickZip.reg file to register context-menu (Zip-Now) for a folder
2. Double-Click rightClickLiveServer.reg file to register context-menu (Live-Server Start) for a folder